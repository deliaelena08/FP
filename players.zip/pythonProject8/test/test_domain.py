from unittest import TestCase


class TestPlayer(TestCase):
    def test_set_id_player(self):
        pass

    def test_set_name(self):
        pass

    def test_set_position(self):
        pass

    def test_set_points(self):
        pass
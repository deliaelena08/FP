from unittest import TestCase
from domain.domain import *
player=Player(1,"MAria",2,10)
class TestPlayer(TestCase):
    def test_get_id_player(self):
        assert self.get_

    def test_get_name(self):
        self.fail()

    def test_get_position(self):
        self.fail()

from unittest import TestCase


class TestInMemoryPlayer(TestCase):
    def test_add_player(self):
        assert

    def test_get_player(self):
        self.fail()

    def test_get_all(self):
        self.fail()

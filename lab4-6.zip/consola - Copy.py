cheltuiala_list=[]
def print_menu_principal():
    print("1.Adauga cheltuiala")
    print("2.Stergere")
    print("3.Cautari")
    print("4.Raportare")
    print("5.Filtrare")
    print("6.Undo")

def menu_1():
    print("1.1 Adaugă o nouă cheltuială (se specifică ziua, suma, tipul) \n2.1 Actualizează cheltuială (se specifică ziua, suma, tipul) ")

def menu_2():
    print("1.2 Șterge toate cheltuielile pentru ziua data")
    print("2.2 Șterge cheltuielile pentru un interval de timp (se dă ziua de început și sfârșit, se șterg toate cheltuielile pentru perioada dată) ")
    print("3.2 Șterge toate cheltuielile de un anumit tip ")

def menu_3():
    print("1.3 Tipărește toate cheltuielile mai mari decât o sumă data")
    print("2.3 Tipărește toate cheltuielile efectuate înainte de o zi dată și mai mici decât o sumă ")
    print("3.3 Tipareste toate cheltuielile de un anumit tip")
def menu_4():
    print("1.4 Tipărește suma totală pentru un anumit tip de cheltuială")
    print("2.4 Găsește ziua în care suma cheltuită e maximă")
    print("3.4 Tipărește toate cheltuielile ce au o anumită sumă")
    print("4.4 Tipărește cheltuielile sortate după tip")

def menu_5():
    print("1.5 Elimină toate cheltuielile de un anumit tip")
    print("2.5 Elimină toate cheltuielile mai mici decât o sumă dată")

def menu_6():
    print("1.6 Reface ultima operație ")


def adaugare_cheltuiala(cheltuiala_list: list, cheltuiala: dict) -> None:
    """
    Adauga o cheltuiala in lista de cheltuieli
    :param cheltuiala_list: lista de cheltuieli
    :type cheltuiala_list: list
    :param cheltuiala: o cheltuiala de adaugat
    :type cheltuiala: dict
    :return: -; modifica lista prin adaugarea la sfarsit a cheltuielei
    :rtype:none
    """
    cheltuiala_list.append(cheltuiala)

def creare_cheltuiala(cheltuiala_str: str) -> dict:
    """
    :param cheltuiala_str: string care reprezinta cheltuiala facuta
    :type cheltuiala_str: str
    :rtype: dictionar
    :return: cheltuiala data
    """
    ziua,suma,tip = cheltuiala_str.split(',')
    ziua = ziua.strip()
    suma = suma.strip()
    suma= int (suma)
    tip = tip.strip()
    cheltuiala_dict = {'ziua': ziua, 'suma': suma, 'tip': tip}
    return cheltuiala_dict

def adaugare_cheltuieli():
    # ui = user interface/interfata cu utilizatorul
    cheltuiala_str = input('Introduceti detaliile cheltuielii separate print-o virgula:')
    cheltuiala = creare_cheltuiala(cheltuiala_str)
    adaugare_cheltuiala(cheltuiala_list, cheltuiala)
    return cheltuiala
